AdventureWorks ASP.NET MVC Application
-------------------------------------------------------------------
The AdventureWorks sample is built based on the AdventureWorks SQL Server sample database.

The sample uses Entity Framework, Linq, jQuery, CSS, and so much more. This is a full blown reference application for the fictitious AdventureWorks store.