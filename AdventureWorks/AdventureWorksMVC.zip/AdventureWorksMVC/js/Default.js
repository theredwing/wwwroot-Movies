﻿$(document).ready(function () {
    $('.islandcontainer').fadeIn('slow');
});