﻿var HostPath = ""; $.support.cors = true;

$(document).ready(function () {
    $("#PnlExpFooter").wijexpander({ expanded: false });
});
